# Verificação da entrega — OrbisV 8.0.0

Data: 23/09/2026.

- 144 testes matemáticos aprovados: 81 exemplos iniciais, casos de referência, invariantes algébricos e rejeição de entradas inválidas.
- 99 testes de interface aprovados em Chromium 153: os 81 módulos executados em Worker; catálogo; treino; exportações; Caderno; reimportação; persistência; preservação de cenas; 12 práticas gráficas; rotação 3D; viewport móvel; filtros de visão de cores; funcionamento offline e abertura por arquivo local.
- Nenhum erro JavaScript não tratado registrado na bateria de interface.
- Referências locais de index.html e do guia verificadas.
- Código-fonte, gerador do Worker, testes e relatórios incluídos.

Relatórios individuais: tests/mathematics-results.json e tests/browser-results.json.
Scripts: tests/mathematics.cjs e tests/browser.mjs.

## Limites da verificação

A bateria não prova correção para toda expressão possível, nem certifica todas as ementas. Cálculos numéricos mantêm as tolerâncias e restrições explicitadas nos módulos. O modo móvel foi verificado por viewport em navegador de desktop; não houve ensaio em aparelhos físicos. Firefox, Safari e empacotadores Electron específicos não foram validados nesta entrega.
