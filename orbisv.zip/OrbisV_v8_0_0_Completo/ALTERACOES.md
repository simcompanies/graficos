# OrbisV 8.0.0 — alterações

- Adicionadas 81 ferramentas específicas às 12 práticas gráficas existentes.
- Catálogo agrupado por conteúdos, com busca por assunto e filtro de grupo.
- Formulários próprios, cálculo simbólico e numérico, tabelas e gráficos vetoriais.
- Projeção 3D com controles de rotação para vetores, retas e superfícies dos módulos.
- Treino com resultados inicialmente ocultos, conferência numérica e registro de hipótese.
- Caderno ampliado para entradas e resultados de experimentos, mantendo cenas e anotações anteriores.
- Exportação dos experimentos em JSON, CSV e SVG.
- Processamento isolado em Worker, cancelamento e limite de execução.
- Motor simbólico incorporado para uso offline; cache atualizado para todos os módulos.
- Matriz de cobertura, guia operacional e testes reproduzíveis incluídos.

A tela inicial, a identidade visual, a organização por conteúdos e o editor gráfico original foram preservados. Não foram acrescentadas aulas teóricas nem níveis de progressão.
