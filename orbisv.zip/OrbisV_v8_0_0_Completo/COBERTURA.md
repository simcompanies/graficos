# Matriz de cobertura — OrbisV 8.0

## Escopo e critério de cobertura

O programa oferece instrumentos para experimentar, calcular, visualizar e registrar atividades. “Cobertura” significa uma operação utilizável, com parâmetros editáveis e saída concreta; não significa exposição teórica, demonstração de teoremas ou resolução universal de todos os exercícios de uma disciplina.

São 93 laboratórios: 81 ferramentas específicas e 12 práticas do editor gráfico. A distribuição de Cálculo II varia conforme a instituição; os 12 módulos de várias variáveis ficam separados para permitir seleção conforme a ementa.

## Fundamentos da Matemática — 23 laboratórios

| Conteúdo / ferramenta | Grupo | Operação disponível |
|---|---|---|
| Operações, potências e radicais | Números e medidas | Calcule expressões e compare representações decimais e científicas. |
| Frações exatas | Números e medidas | Opere frações e obtenha a forma irredutível. |
| Divisibilidade, MDC e MMC | Números e medidas | Fatorem inteiros e compare divisores comuns. |
| Razões, proporções e porcentagens | Números e medidas | Resolva proporções diretas, inversas e variações percentuais. |
| Conversão de unidades | Números e medidas | Converta comprimento, área, volume, massa, tempo e temperatura. |
| Conjuntos e operações | Lógica e conjuntos | Compare conjuntos finitos e pares ordenados. |
| Tabela de proposições | Lógica e conjuntos | Teste negação, conjunção, disjunção, implicação e equivalência. |
| Expressões, produtos e fatoração | Álgebra e funções | Expanda, fatore e simplifique expressões. |
| Equações em uma variável | Álgebra e funções | Resolva equações polinomiais e procure raízes reais de funções. |
| Inequações lineares e quadráticas | Álgebra e funções | Determine intervalos para ax² + bx + c em relação a zero. |
| Composição e transformações | Álgebra e funções | Compare f, g, composições e transformações de gráficos. |
| Exponenciais e logaritmos | Álgebra e funções | Resolva b^x = y e explore a função exponencial. |
| Progressões aritméticas e geométricas | Sequências e dados | Liste e some os termos de uma PA ou PG. |
| Círculo trigonométrico | Geometria e trigonometria | Explore ângulos, seno, cosseno, tangente e periodicidade. |
| Triângulos e relações métricas | Geometria e trigonometria | Calcule ângulos, área, alturas e raios a partir dos lados. |
| Áreas e perímetros | Geometria e trigonometria | Meça retângulos, círculos, trapézios e polígonos regulares. |
| Volumes e áreas de sólidos | Geometria e trigonometria | Meça esferas, cilindros, cones, prismas e pirâmides. |
| Números complexos | Álgebra e funções | Opere pares real e imaginário e compare a forma polar. |
| Combinatória e probabilidade binomial | Sequências e dados | Calcule permutações, arranjos, combinações e probabilidades. |
| Estatística descritiva | Sequências e dados | Resuma amostras e compare frequências. |
| Juros e crescimento | Sequências e dados | Compare juros simples e compostos com períodos compatíveis. |
| Funções e gráficos | Laboratório gráfico livre | Edite expressões e compare seus gráficos no plano cartesiano. |
| Modelos de variação | Laboratório gráfico livre | Trabalhe com funções lineares, quadráticas, exponenciais e trigonométricas. |

## Geometria Analítica — 12 laboratórios

| Conteúdo / ferramenta | Grupo | Operação disponível |
|---|---|---|
| Pontos, distâncias e segmentos | Coordenadas e retas | Meça segmentos 2D e 3D e localize pontos intermediários. |
| Relações entre retas no plano | Coordenadas e retas | Interseções, distância ponto–reta e ângulos. |
| Circunferência e interseções | Cônicas | Calcule interseções entre circunferências e retas. |
| Elipse, hipérbole e parábola | Cônicas | Explore parâmetros, focos, excentricidade e forma das cônicas. |
| Classificação de cônicas gerais | Cônicas | Classifique Ax² + Bxy + Cy² + Dx + Ey + F = 0 e calcule a rotação. |
| Reta e plano no espaço | Geometria do espaço | Interseção, projeção e distância de ponto a plano. |
| Interseção de planos | Geometria do espaço | Compare planos e obtenha uma reta de interseção. |
| Coordenadas polares, cilíndricas e esféricas | Geometria do espaço | Converta coordenadas e visualize o vetor posição. |
| Superfícies quádricas | Geometria do espaço | Explore elipsoides, paraboloides e hiperboloides em 3D. |
| Polígonos por coordenadas | Coordenadas e retas | Meça perímetro, área orientada e centroide. |
| Construções no plano | Laboratório gráfico livre | Crie pontos, retas, círculos, elipses e polígonos editáveis. |
| Retas no espaço | Laboratório gráfico livre | Defina uma reta por dois pontos ou por um ponto e um vetor diretor. |

## Álgebra Vetorial — 11 laboratórios

| Conteúdo / ferramenta | Grupo | Operação disponível |
|---|---|---|
| Operações e produtos vetoriais | Vetores e produtos | Soma, produto escalar, produto vetorial, ângulo e projeção. |
| Produto misto e volumes | Vetores e produtos | Verifique coplanaridade e meça paralelepípedos e tetraedros. |
| Operações com matrizes | Matrizes e sistemas | Some, multiplique, transponha e inverta matrizes; calcule determinantes. |
| Sistemas lineares e escalonamento | Matrizes e sistemas | Eliminação com pivoteamento, posto e variáveis livres. |
| Dependência linear, bases e núcleo | Espaços vetoriais | Calcule posto, colunas independentes e base do núcleo. |
| Ortogonalização de Gram–Schmidt | Espaços vetoriais | Obtenha base ortonormal para o espaço gerado pelos vetores. |
| Transformações lineares e afins | Transformações | Aplique rotações, reflexões, escalas, cisalhamentos e translações. |
| Autovalores e autoespaços 2 × 2 | Transformações | Calcule espectro real ou complexo de matrizes 2 × 2. |
| Ajuste por mínimos quadrados | Matrizes e sistemas | Ajuste y = ax + b e examine resíduos. |
| Vetores no plano | Laboratório gráfico livre | Defina a origem e a extremidade e compare módulo e direção. |
| Trajetórias paramétricas | Laboratório gráfico livre | Edite x(t), y(t) e o intervalo do parâmetro. |

## Cálculo I — 15 laboratórios

| Conteúdo / ferramenta | Grupo | Operação disponível |
|---|---|---|
| Limites laterais e no infinito | Limites e continuidade | Compare aproximações pela esquerda, direita ou em direção ao infinito. |
| Verificação de ε e δ | Limites e continuidade | Teste uma escolha de δ para o limite proposto L. |
| Derivação simbólica e ordens superiores | Derivadas | Derive composições, produtos, quocientes e funções elementares. |
| Secantes, tangentes e aproximação linear | Derivadas | Compare taxa média, taxa instantânea e erro da linearização. |
| Derivadas implícitas | Derivadas | Calcule dy/dx para F(x,y) = 0 em um ponto da curva. |
| Taxas relacionadas | Derivadas | Use F(x,y)=0, x(t) e uma taxa conhecida para obter dy/dt. |
| Crescimento, concavidade e pontos críticos | Aplicações de derivadas | Compare f, f′ e f″ e procure candidatos a extremos e inflexões. |
| Extremos em intervalo fechado | Aplicações de derivadas | Compare extremos candidatos e valores nas extremidades. |
| Método de Newton | Aplicações de derivadas | Acompanhe iterações, resíduos e aproximações de uma raiz. |
| Comparação de quocientes 0/0 | Limites e continuidade | Compare f/g e f′/g′ em uma indeterminação candidata. |
| Polinômios de Taylor e Maclaurin | Aproximações e integrais | Construa polinômios e compare o erro em um ponto. |
| Somas de Riemann | Aproximações e integrais | Compare somas à esquerda, à direita e pelos pontos médios. |
| Acumulação e Teorema Fundamental | Aproximações e integrais | Compare integral definida, primitiva proposta e diferença de extremos. |
| Limites e continuidade | Laboratório gráfico livre | Examine aproximações, descontinuidades e assíntotas no gráfico. |
| Derivadas e variação | Laboratório gráfico livre | Represente derivadas numéricas e compare crescimento e extremos. |

## Cálculo II — 32 laboratórios

| Conteúdo / ferramenta | Grupo | Operação disponível |
|---|---|---|
| Primitivas simbólicas | Técnicas de integração | Integre funções elementares, racionais e trigonométricas. |
| Integração por substituição | Técnicas de integração | Defina x = g(u) e examine o integrando transformado e os limites. |
| Integração por partes | Técnicas de integração | Escolha u e dv/dx e compare os termos da identidade. |
| Frações parciais | Técnicas de integração | Decomponha funções racionais para preparar a integração. |
| Substituição trigonométrica | Técnicas de integração | Transforme integrais usando x = a sen(t), a tg(t) ou a sec(t). |
| Integração numérica e comparação de regras | Integrais e aplicações | Compare pontos médios, trapézios, Simpson e quadratura adaptativa. |
| Integrais impróprias | Integrais e aplicações | Compare truncamentos e aplique o critério das potências em famílias conhecidas. |
| Áreas entre curvas e centroides | Integrais e aplicações | Meça área e centroide de lâmina uniforme entre duas funções. |
| Volumes por cascas e seções | Integrais e aplicações | Calcule cascas em torno do eixo y ou integre uma área de seção. |
| Comprimento de arco e área de revolução | Integrais e aplicações | Meça o arco de y=f(x) e a superfície gerada em torno de x. |
| Trabalho, valor médio e massa | Integrais e aplicações | Integre forças e densidades e calcule médias e centros de massa. |
| Medidas de curvas paramétricas e polares | Curvas e equações diferenciais | Calcule comprimento e integral de área orientada de curvas planas. |
| Equações diferenciais de primeira ordem | Curvas e equações diferenciais | Compare Euler e Runge–Kutta para y′ = f(x,y) com condição inicial. |
| Sequências e somas parciais | Sequências e séries | Explore termos, somas, razões e raízes de termos de uma série. |
| Séries: critérios em famílias conhecidas | Sequências e séries | Classifique séries geométricas, p-séries e p-séries alternadas. |
| Séries de potências e intervalos | Sequências e séries | Compare séries clássicas, raios e comportamento nas extremidades. |
| Funções de duas variáveis e superfícies | Várias variáveis | Explore z = f(x,y), domínio amostrado e curvas de nível. |
| Limites em várias variáveis: caminhos | Várias variáveis | Compare aproximações por retas e parábolas até a origem. |
| Derivadas parciais, gradiente e Hessiana | Várias variáveis | Calcule derivadas de primeira e segunda ordem e classifique pontos estacionários. |
| Derivada direcional e plano tangente | Várias variáveis | Compare direções e construa a linearização de z = f(x,y). |
| Integrais duplas com limites variáveis | Várias variáveis | Integre sobre regiões a ≤ x ≤ b, g(x) ≤ y ≤ h(x). |
| Integrais duplas em polares | Várias variáveis | Integre f(x,y) com limites radiais e fator jacobiano r. |
| Integrais triplas cartesianas | Várias variáveis | Integre com limites variáveis e ordem dz dy dx. |
| Mudança de variáveis e jacobiano | Várias variáveis | Transforme uma integral dupla sobre um retângulo no plano uv. |
| Restrição por multiplicadores de Lagrange | Várias variáveis | Refine um candidato a extremo de f(x,y) sujeito a g(x,y)=0. |
| Campos vetoriais, divergência e rotacional | Várias variáveis | Avalie campos tridimensionais e suas derivadas. |
| Integrais de linha e trabalho | Várias variáveis | Calcule ∫ F·dr ao longo de uma curva paramétrica no espaço. |
| Área e fluxo em superfícies | Várias variáveis | Meça uma superfície z=h(x,y) e fluxo com normal voltada para cima. |
| Discos e anéis | Laboratório gráfico livre | Edite os raios, o eixo e o intervalo e visualize o sólido de revolução. |
| Integrais definidas | Laboratório gráfico livre | Teste expressões de integração numérica no editor matemático. |
| Curvas paramétricas | Laboratório gráfico livre | Explore formas, laços e intervalos em curvas do plano. |
| Curvas no espaço | Laboratório gráfico livre | Edite x(t), y(t), z(t) e observe a curva com a câmera orbital. |

## Profundidade e extensões possíveis

| Núcleo | Cobertura atual e limite | Forma de ampliar sem transformar o programa em apostila |
|---|---|---|
| Aritmética e números | Frações exatas, MDC/MMC, expressões e medidas; conjuntos são finitos | Acrescentar representações arrastáveis de frações e reta numérica para atividades visuais nos anos iniciais |
| Álgebra e funções | Simplificação, fatoração, composição, transformações e raízes reais; domínio não é resolvido simbolicamente em geral | Acrescentar um editor por partes, análise de intervalos de domínio e construção interativa de inversas com seleção de ramos |
| Geometria elementar | Medidas de figuras usuais e polígonos; polígonos pressupõem contorno simples | Acrescentar construções por régua e compasso com vínculos geométricos e detecção de cruzamentos |
| Trigonometria | Círculo, funções no editor, triângulos por três lados e substituições trigonométricas | Acrescentar triângulos por lado–ângulo, com tratamento explícito do caso ambíguo SSA e manipulação de identidades |
| Probabilidade e dados | Combinatória, binomial, frequências, medidas descritivas e ajuste linear | Acrescentar árvore de probabilidade, probabilidade condicional, Bayes e amostragem aleatória; inferência estatística é uma extensão ao percurso principal |
| Geometria analítica | Retas, cônicas, planos, coordenadas e quádricas; classificação geral distingue famílias e degenerescência numérica | Acrescentar interseções exatas entre superfícies e classificação detalhada de todas as cônicas degeneradas |
| Álgebra vetorial | Produtos, projeções, matrizes até 8 × 8, sistemas, bases e ortogonalização; autovalores limitados a 2 × 2 | Acrescentar decomposições QR/SVD, autovalores gerais, métricas de condicionamento e transformações 3D editáveis |
| Limites e continuidade | Tabelas laterais, infinito, ε–δ por amostragem e comparação de caminhos; não há prova automática | Acrescentar limites simbólicos laterais com certificado de condições e testes por intervalos, sem confundir amostragem com prova |
| Derivadas e aplicações | Derivação simbólica, implícitas, taxas, tangentes, Taylor, Newton e candidatos a extremos | Acrescentar funções por partes, isolamento garantido de raízes e classificação explícita de pontos não diferenciáveis |
| Integração | Primitivas compatíveis com o motor, partes, substituição, frações parciais, quadratura e aplicações | Acrescentar análise automática de polos, primitivas por ramos reais e limites de erro certificados |
| Séries | Somas parciais, razões e raízes amostradas; critérios analíticos para geométricas, p-séries e p-séries alternadas; cinco séries clássicas | Acrescentar comparação entre duas séries, teste integral e análise simbólica de razão/raiz, incluindo casos inconclusivos e extremidades de séries genéricas |
| Equações diferenciais | Problema de valor inicial escalar de primeira ordem por Euler/RK4 | Acrescentar soluções simbólicas de famílias separáveis e lineares, campos de direções, sistemas de EDO e passo adaptativo |
| Várias variáveis | Parciais, gradiente, Hessiana, direcionais, plano tangente, integrais duplas/triplas, jacobiano e candidato de Lagrange | Acrescentar decomposição de regiões gerais, singularidades, restrições múltiplas e busca global de candidatos |
| Cálculo vetorial | Divergência, rotacional, trabalho ao longo de curvas e fluxo por gráficos de superfícies | Acrescentar comparação experimental dos dois lados de Green, Gauss e Stokes, com orientação e hipóteses verificadas; usualmente conteúdo posterior ao Cálculo II |

As sugestões acima descrevem maior profundidade e novos tipos de interação. Nenhuma delas é apresentada no catálogo como se já estivesse implementada. Não foram incluídos conteúdos de álgebra abstrata, topologia, análise real avançada ou outras disciplinas fora do percurso estabelecido.

## Referências para organização dos conteúdos

Consulta às estruturas curriculares das fontes abaixo; não foram copiados capítulos, imagens ou bancos de exercícios. O agrupamento no OrbisV é uma adaptação para ferramenta de apoio e prática, não uma equivalência oficial de ementas.

- OpenStax. **Precalculus 2e**. Funções, composição, transformações e inversas: https://openstax.org/books/precalculus-2e/pages/1-introduction-to-functions
- OpenStax. **Calculus Volume 1**. Funções, limites, derivadas e introdução à integração: https://openstax.org/books/calculus-volume-1/pages/1-introduction
- OpenStax. **Calculus Volume 2**, capítulo 3. Técnicas de integração: https://openstax.org/books/calculus-volume-2/pages/3-introduction
- OpenStax. **Calculus Volume 2**, capítulo 5. Sequências e séries: https://openstax.org/books/calculus-volume-2/pages/5-introduction
- OpenStax. **Calculus Volume 2**, capítulo 6. Séries de potências e Taylor: https://openstax.org/books/calculus-volume-2/pages/6-introduction
- OpenStax. **Calculus Volume 3**, capítulos 1, 4 e 5. Curvas, várias variáveis e integrais múltiplas: https://openstax.org/books/calculus-volume-3/pages/4-introduction
- MIT OpenCourseWare. **18.06 Linear Algebra**, Spring 2010. Sistemas, espaços vetoriais e transformações: https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/pages/syllabus/

Data de fechamento da matriz: 23 de setembro de 2026.
